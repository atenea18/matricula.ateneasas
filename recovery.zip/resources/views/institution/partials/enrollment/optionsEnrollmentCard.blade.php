<ul class="nav nav-tabs">
    <li role="presentation" class="{{App\Helpers\helpsRoute::activeMenu('institution/enrollment-card/grade')}}"><a href="{{route('enrollment.card.grade')}}">Grado</a></li>
    <li role="presentation" class="{{App\Helpers\helpsRoute::activeMenu('institution/enrollment-card/group')}}"><a href="{{route
    ('enrollment.card.group')}}">Grupo</a></li>
    <!--<li role="presentation" class="{{App\Helpers\helpsRoute::activeMenu('institution/enrollment-card/student')}}"><a
                href="{{route
    ('enrollment.card.student')}}">Estudiante</a></li>-->
</ul>
