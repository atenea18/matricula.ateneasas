@extends('institution.layout')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-success">
                <div class="panel-heading">Institution's Dashboard</div>

                <div class="panel-body">
                    Greetings.. Institution
                </div>
            </div>
        </div>
    </div>
</div>
@endsection